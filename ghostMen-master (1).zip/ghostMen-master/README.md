# ghostMen
Used TensorFlow with neural net to build a sequential model with 3 layers. Activation functions were relu, relu and sigmoid.

This resulted in around a 72% accuracy rate
